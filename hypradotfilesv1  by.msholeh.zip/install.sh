#!/bin/bash
# ═══════════════════════════════════════════════════════════
#   HYPRLAND GLASS — Install Script
#   Full Translucent / Glassmorphism Theme
# ═══════════════════════════════════════════════════════════

set -e
BOLD="\e[1m"
CYAN="\e[36m"
GREEN="\e[32m"
YELLOW="\e[33m"
RESET="\e[0m"

echo -e "${CYAN}${BOLD}"
echo "  ██████╗ ██╗      █████╗ ███████╗███████╗"
echo "  ██╔════╝ ██║     ██╔══██╗██╔════╝██╔════╝"
echo "  ██║  ███╗██║     ███████║███████╗███████╗"
echo "  ██║   ██║██║     ██╔══██║╚════██║╚════██║"
echo "  ╚██████╔╝███████╗██║  ██║███████║███████║"
echo "  HYPRLAND GLASS THEME INSTALLER"
echo -e "${RESET}"

# ── 1. Install dependencies ──────────────────────────────
echo -e "${YELLOW}[1/5] Installing packages...${RESET}"
sudo pacman -S --needed --noconfirm \
    hyprland hyprpaper hyprlock \
    waybar \
    wofi \
    mako \
    kitty \
    firefox \
    thunar \
    pipewire wireplumber pavucontrol \
    networkmanager network-manager-applet \
    grim slurp wl-clipboard \
    brightnessctl \
    papirus-icon-theme \
    ttf-jetbrains-mono-nerd \
    polkit-gnome \
    wlogout

# AUR packages (using yay)
if command -v yay &>/dev/null; then
    echo -e "${YELLOW}[AUR] Installing AUR packages...${RESET}"
    yay -S --needed --noconfirm \
        adw-gtk3 \
        bibata-cursor-theme \
        hyprland-git || true
fi

# ── 2. Backup existing configs ───────────────────────────
echo -e "${YELLOW}[2/5] Backing up existing configs...${RESET}"
BACKUP="$HOME/.config-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
for dir in hypr waybar wofi mako gtk-3.0; do
    [ -d "$HOME/.config/$dir" ] && cp -r "$HOME/.config/$dir" "$BACKUP/" && \
        echo "  → Backed up ~/.config/$dir"
done
echo "  → Backup saved to $BACKUP"

# ── 3. Copy config files ─────────────────────────────────
echo -e "${YELLOW}[3/5] Copying config files...${RESET}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p ~/.config/{hypr,waybar,wofi,mako,gtk-3.0}

cp "$SCRIPT_DIR/hypr/hyprland.conf"   ~/.config/hypr/
cp "$SCRIPT_DIR/hypr/hyprlock.conf"   ~/.config/hypr/
cp "$SCRIPT_DIR/hypr/hyprpaper.conf"  ~/.config/hypr/
cp "$SCRIPT_DIR/waybar/config.jsonc"  ~/.config/waybar/
cp "$SCRIPT_DIR/waybar/style.css"     ~/.config/waybar/
cp "$SCRIPT_DIR/wofi/config"          ~/.config/wofi/
cp "$SCRIPT_DIR/wofi/style.css"       ~/.config/wofi/
cp "$SCRIPT_DIR/mako/config"          ~/.config/mako/
cp "$SCRIPT_DIR/gtk-3.0/settings.ini" ~/.config/gtk-3.0/

echo -e "${GREEN}  ✓ Config files installed${RESET}"

# ── 4. Set wallpaper placeholder ─────────────────────────
echo -e "${YELLOW}[4/5] Setting up wallpaper...${RESET}"
mkdir -p ~/Pictures
if [ ! -f ~/Pictures/wallpaper.jpg ]; then
    echo -e "${YELLOW}  ⚠  Letakkan wallpaper di ~/Pictures/wallpaper.jpg"
    echo     "     Rekomendasi: wallpaper gelap (biru tua / ungu / hitam)"
    echo     "     agar efek glass blur terlihat maksimal"
fi

# ── 5. Enable services ───────────────────────────────────
echo -e "${YELLOW}[5/5] Enabling services...${RESET}"
systemctl --user enable --now pipewire pipewire-pulse wireplumber 2>/dev/null || true

echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════"
echo "  ✓ HYPRLAND GLASS THEME INSTALLED!"
echo "═══════════════════════════════════════════${RESET}"
echo ""
echo "  Langkah berikutnya:"
echo "  1. Letakkan wallpaper di ~/Pictures/wallpaper.jpg"
echo "  2. Jalankan: Hyprland"
echo "  3. Atau logout dan pilih Hyprland di display manager"
echo ""
echo -e "  Keybind penting:"
echo "  Super + Enter   → Terminal (kitty)"
echo "  Super + R       → App Launcher (wofi)"  
echo "  Super + B       → Browser (firefox)"
echo "  Super + E       → File Manager (thunar)"
echo "  Super + Q       → Tutup window"
echo "  Super + L       → Lock screen"
echo "  Super + F       → Fullscreen"
echo "  Super + V       → Toggle floating"
echo "  Print           → Screenshot area"
echo ""
